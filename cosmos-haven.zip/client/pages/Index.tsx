import AppLayout, { Project, Message } from "@/components/AppLayout";
import TrialChat from "@/components/TrialChat";

export default function Index() {
  return (
    <AppLayout>
      {({
        projects,
        activeProjectId,
        onUpdateProjectMessages,
      }: {
        projects: Project[];
        activeProjectId: string | null;
        onUpdateProjectMessages: (projectId: string, messages: Message[]) => void;
      }) => (
        <TrialChat
          projects={projects}
          activeProjectId={activeProjectId}
          onUpdateProjectMessages={onUpdateProjectMessages}
        />
      )}
    </AppLayout>
  );
}
