import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Plus, FileText, Trash2, Brain } from "lucide-react";
import { cn } from "@/lib/utils";
import { Project } from "@/components/AppLayout";

interface SidebarProps {
  projects: Project[];
  activeProjectId: string | null;
  onSelectProject: (projectId: string) => void;
  onNewProject: (name: string) => void;
  onDeleteProject: (projectId: string) => void;
}

export default function Sidebar({
  projects,
  activeProjectId,
  onSelectProject,
  onNewProject,
  onDeleteProject,
}: SidebarProps) {
  const [showNewProjectDialog, setShowNewProjectDialog] = useState(false);
  const [projectName, setProjectName] = useState("");

  const handleCreateProject = () => {
    if (projectName.trim()) {
      onNewProject(projectName);
      setProjectName("");
      setShowNewProjectDialog(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleCreateProject();
    } else if (e.key === "Escape") {
      setShowNewProjectDialog(false);
      setProjectName("");
    }
  };

  return (
    <>
      <div className="h-screen w-72 flex flex-col border-r border-border bg-background">
        {/* Logo and New Project Section */}
        <div className="p-4 space-y-4">
          {/* Logo */}
          <div className="flex items-center justify-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-accent">
              <Brain className="h-6 w-6 text-white" />
            </div>
          </div>

          {/* New Project Button */}
          <Button
            onClick={() => setShowNewProjectDialog(true)}
            className="w-full bg-gradient-to-r from-primary/80 to-accent/80 text-white rounded-lg flex items-center gap-2 hover:scale-105 transition-transform duration-200"
          >
            <Plus className="h-4 w-4" />
            New Project
          </Button>
        </div>

        {/* Projects List */}
        <div className="flex-1 overflow-y-auto px-3 py-2">
          {projects.length === 0 ? (
            <p className="text-xs text-muted-foreground text-center py-8">
              No projects yet. Create one to get started!
            </p>
          ) : (
            <div className="space-y-2">
              {projects.map((project) => (
                <div
                  key={project.id}
                  className={cn(
                    "flex items-center gap-2 p-3 rounded-lg cursor-pointer transition-transform duration-200 group hover:scale-105",
                    activeProjectId === project.id
                      ? "bg-primary/10 text-primary"
                      : "text-foreground"
                  )}
                  onClick={() => onSelectProject(project.id)}
                >
                  <FileText className="h-4 w-4 flex-shrink-0" />
                  <span className="text-sm font-medium truncate flex-1">
                    {project.name}
                  </span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteProject(project.id);
                    }}
                    className="opacity-0 group-hover:opacity-100 transition p-1 hover:bg-destructive/10 rounded"
                  >
                    <Trash2 className="h-3 w-3 text-destructive" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* New Project Dialog */}
      {showNewProjectDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-card rounded-2xl border border-border shadow-lg p-6 max-w-md w-full mx-4">
            <h2 className="text-lg font-semibold text-foreground mb-4">
              Create New Project
            </h2>
            <input
              type="text"
              placeholder="Enter project name..."
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
              onKeyDown={handleKeyDown}
              autoFocus
              className="w-full border border-input bg-background rounded-lg px-4 py-2 text-sm text-foreground placeholder-muted-foreground outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20 mb-4"
            />
            <div className="flex gap-2 justify-end">
              <Button
                onClick={() => {
                  setShowNewProjectDialog(false);
                  setProjectName("");
                }}
                variant="outline"
                className="rounded-lg"
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreateProject}
                disabled={!projectName.trim()}
                className="bg-gradient-to-r from-primary to-accent text-white rounded-lg disabled:opacity-50"
              >
                Create
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
