import { useState, ReactNode } from "react";
import Sidebar from "@/components/Sidebar";

export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

export interface Project {
  id: string;
  name: string;
  createdAt: Date;
  lastEdited: Date;
  messages: Message[];
}

interface AppLayoutProps {
  children: (props: { projects: Project[]; activeProjectId: string | null }) => ReactNode;
  onSelectProject?: (projectId: string) => void;
  onNewProject?: (name: string) => void;
}

export default function AppLayout({
  children,
  onSelectProject,
  onNewProject,
}: AppLayoutProps) {
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);

  const handleNewProject = (name: string) => {
    const now = new Date();
    const newProject: Project = {
      id: Date.now().toString(),
      name,
      createdAt: now,
      lastEdited: now,
      messages: [],
    };
    setProjects([newProject, ...projects]);
    setActiveProjectId(newProject.id);
    onNewProject?.(name);
  };

  const handleUpdateProjectTime = (projectId: string) => {
    setProjects(
      projects.map((p) =>
        p.id === projectId ? { ...p, lastEdited: new Date() } : p
      )
    );
  };

  const handleUpdateProjectMessages = (projectId: string, messages: Message[]) => {
    setProjects(
      projects.map((p) =>
        p.id === projectId ? { ...p, messages, lastEdited: new Date() } : p
      )
    );
  };

  const handleSelectProject = (projectId: string) => {
    setActiveProjectId(projectId);
    onSelectProject?.(projectId);
  };

  const handleDeleteProject = (projectId: string) => {
    setProjects(projects.filter((p) => p.id !== projectId));
    if (activeProjectId === projectId) {
      setActiveProjectId(projects.length > 1 ? projects[0].id : null);
    }
  };

  return (
    <div className="flex h-screen bg-background">
      <Sidebar
        projects={projects}
        activeProjectId={activeProjectId}
        onSelectProject={handleSelectProject}
        onNewProject={handleNewProject}
        onDeleteProject={handleDeleteProject}
      />

      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Main Content */}
        {typeof children === "function"
          ? children({
              projects,
              activeProjectId,
              onUpdateProjectMessages: handleUpdateProjectMessages,
            })
          : children}
      </div>
    </div>
  );
}
