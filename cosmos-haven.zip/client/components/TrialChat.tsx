import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Send, Brain } from "lucide-react";
import { cn } from "@/lib/utils";
import { DoctorResponse } from "@shared/api";
import { Project, Message } from "@/components/AppLayout";

interface TrialChatProps {
  projects?: Project[];
  activeProjectId?: string | null;
  onUpdateProjectMessages?: (projectId: string, messages: Message[]) => void;
}

export default function TrialChat({
  projects = [],
  activeProjectId,
  onUpdateProjectMessages,
}: TrialChatProps) {
  const [doctorName, setDoctorName] = useState<string>("");
  const [showWelcome, setShowWelcome] = useState(true);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingDoctor, setIsLoadingDoctor] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const activeProject = projects.find((p) => p.id === activeProjectId);
  const messages = activeProject?.messages || [];

  const setMessages = (newMessages: Message[]) => {
    if (activeProjectId && onUpdateProjectMessages) {
      onUpdateProjectMessages(activeProjectId, newMessages);
    }
  };

  useEffect(() => {
    const fetchDoctor = async () => {
      try {
        const response = await fetch("/api/doctor");
        const data: DoctorResponse = await response.json();
        setDoctorName(data.name);
      } catch (error) {
        console.error("Error fetching doctor:", error);
        setDoctorName("Doctor");
      } finally {
        setIsLoadingDoctor(false);
      }
    };

    fetchDoctor();
  }, []);

  useEffect(() => {
    if (!showWelcome && inputRef.current) {
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, [showWelcome]);

  useEffect(() => {
    if (activeProjectId && messages.length > 0) {
      setShowWelcome(false);
    } else {
      setShowWelcome(true);
    }
  }, [activeProjectId, messages.length]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleGetStarted = () => {
    const welcomeMessage: Message = {
      id: "welcome",
      role: "assistant",
      content: `What would you like to do today, Dr. ${doctorName}?`,
      timestamp: new Date(),
    };
    setMessages([welcomeMessage]);
    setShowWelcome(false);
  };

  const handleContinueResearch = () => {
    const mostRecentProject = projects.reduce((latest, current) =>
      current.lastEdited > latest.lastEdited ? current : latest
    );

    const welcomeMessage: Message = {
      id: "welcome",
      role: "assistant",
      content: `Welcome back, Dr. ${doctorName}. Continuing with "${mostRecentProject.name}". What would you like to explore today?`,
      timestamp: new Date(),
    };
    setMessages([welcomeMessage]);
    setShowWelcome(false);
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: inputValue,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");
    setIsLoading(true);

    setTimeout(() => {
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content:
          "I understand you're interested in clinical trials. Let me help you find relevant trials based on your needs. Could you tell me more about your research interests?",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, assistantMessage]);
      setIsLoading(false);
    }, 800);

    inputRef.current?.focus();
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (showWelcome && !isLoadingDoctor) {
    return (
      <div className="flex h-full flex-col bg-background overflow-hidden">
        {/* Welcome Message */}
        <div className="flex flex-1 flex-col items-center justify-center px-4 py-6">
          <div className="max-w-2xl text-center sm:text-left">
            <h2 className="text-4xl sm:text-5xl font-bold text-foreground leading-tight mb-4">
              What would you like to do today,{" "}
              <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                Dr. {doctorName}?
              </span>
            </h2>
            <p className="text-lg text-muted-foreground mb-8 max-w-lg">
              Welcome back to TrialMatch. I'm here to help you navigate clinical
              trials and research opportunities with ease.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={handleGetStarted}
                className="bg-gradient-to-r from-primary to-accent text-white px-8 py-3 rounded-2xl hover:shadow-lg"
              >
                Get Started
              </Button>
              {projects.length > 0 && (
                <Button
                  onClick={handleContinueResearch}
                  variant="outline"
                  className="px-8 py-3 rounded-2xl border-primary text-primary hover:bg-primary/5"
                >
                  Continue Research
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-full flex-col bg-background overflow-hidden">
      {/* Centered Chat Container */}
      <div className="flex flex-1 flex-col items-center justify-center px-4 py-4 sm:py-6 overflow-hidden">
        <div className="w-full max-w-4xl rounded-2xl border border-border bg-card shadow-lg flex flex-col h-full">
          {/* Messages Area */}
          <div className="flex flex-1 flex-col overflow-y-auto p-6 sm:p-8">
            {messages.map((message) => (
              <div
                key={message.id}
                className={cn(
                  "mb-4 flex gap-3 animate-in fade-in slide-in-from-bottom-3",
                  message.role === "user" ? "justify-end" : "justify-start"
                )}
              >
                {message.role === "assistant" && (
                  <div className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-accent">
                    <Brain className="h-4 w-4 text-white" />
                  </div>
                )}

                <div
                  className={cn(
                    "max-w-xs rounded-2xl px-4 py-3 text-sm leading-relaxed sm:max-w-sm",
                    message.role === "assistant"
                      ? "bg-primary/10 text-foreground"
                      : "bg-gradient-to-r from-primary to-accent text-white"
                  )}
                >
                  {message.id === "welcome" ? (
                    <p className="text-base sm:text-lg font-semibold">
                      {message.content}
                    </p>
                  ) : (
                    <p className="whitespace-pre-wrap">{message.content}</p>
                  )}
                </div>

                {message.role === "user" && (
                  <div className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-lg bg-muted">
                    <span className="text-xs font-semibold text-muted-foreground">
                      U
                    </span>
                  </div>
                )}
              </div>
            ))}

            {isLoading && (
              <div className="mb-4 flex gap-3">
                <div className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-accent">
                  <Brain className="h-4 w-4 text-white" />
                </div>
                <div className="flex items-center gap-1 rounded-2xl bg-primary/10 px-4 py-2 text-foreground">
                  <div className="flex gap-1">
                    <div className="h-2 w-2 rounded-full bg-primary/60 animate-bounce" />
                    <div className="animation-delay-100 h-2 w-2 rounded-full bg-primary/60 animate-bounce" />
                    <div className="animation-delay-200 h-2 w-2 rounded-full bg-primary/60 animate-bounce" />
                  </div>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="border-t border-border px-6 py-4 sm:px-8 sm:py-5">
            <div className="flex gap-2 sm:gap-3">
              <input
                ref={inputRef}
                type="text"
                placeholder="Ask your question..."
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                disabled={isLoading}
                className="flex-1 rounded-2xl border border-input bg-background px-4 py-2 text-sm text-foreground placeholder-muted-foreground outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20 disabled:opacity-50 sm:px-5 sm:py-3"
              />
              <Button
                onClick={handleSendMessage}
                disabled={!inputValue.trim() || isLoading}
                className="flex-shrink-0 rounded-2xl bg-gradient-to-r from-primary to-accent px-4 text-white hover:shadow-lg disabled:opacity-50 sm:px-5"
              >
                <Send className="h-4 w-4 sm:h-5 sm:w-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <p className="mt-6 text-center text-xs text-muted-foreground">
          Powered by TrialMatch Intelligence • Always consult healthcare
          professionals
        </p>
      </div>
    </div>
  );
}
